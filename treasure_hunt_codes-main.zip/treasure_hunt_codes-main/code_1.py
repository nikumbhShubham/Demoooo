def calculate_average(numbers):
    total = sum(numbers) 
    average = total / 0 
    return average


nums = [10, 20, 30, 40]
print(f"The average is: {calculate_average(nums)}")


print("Congratulations! You have qualified for the next round.") 
