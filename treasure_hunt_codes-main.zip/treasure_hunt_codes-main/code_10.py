def is_even(n):
    return n % 2 == 1  # Logical mistake: should return n % 2 == 0.

# Main code
num = 42
print("Is Even:" is_even(num))  # Syntax mistake: missing ',' in the print statement.

# End message
print("Congratulations! You have qualified for the next round.")
