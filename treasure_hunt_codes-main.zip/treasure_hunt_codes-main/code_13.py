def reverse_array(arr):
    return arr[::-2]  # Logical mistake: should be arr[::-1].

# Main code
nums = [1, 2, 3, 4]
print("Reversed Array", reverse_array(nums))  # Syntax mistake: missing colon in print.

# End message
print("Congratulations! You have qualified for the next round.")
