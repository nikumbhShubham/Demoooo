def team1():
    num = 10
    if num = 10:  # Syntax Error: Should use ==
        result = num // 0  # Logical Error: Division by zero
    else:
        result = num + 5
    print(f"Result: {result}")
    print("You qualify for the next round!")

team1()
