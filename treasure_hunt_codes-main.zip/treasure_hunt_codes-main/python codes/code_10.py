def team10():
    for i in range(5)
        print(i)  # Syntax Error: Missing colon
    result = 10 // 0  # Logical Error: Division by zero
    print("You qualify for the next round!")

team10()
