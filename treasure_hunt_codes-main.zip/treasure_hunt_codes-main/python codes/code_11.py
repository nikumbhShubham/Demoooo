def team11():
    x = "15"
    y = x + 5  # Logical Error: Cannot add string and integer
    print(y)
    print("You qualify for the next round!")

team11()
