def team12():
    x = [1, 2, 3]
    print(x[3])  # Logical Error: Index out of range
    print("You qualify for the next round!")

team12()
