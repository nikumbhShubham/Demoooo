def team13():
    a = 10
    b = 20
    if a > b:  # Logical Error: Condition is False, but no handling
        print("a is greater")
    print("You qualify for the next round!")

team13()
