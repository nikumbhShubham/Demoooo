def team14():
    num1 = "100"
    num2 = 50
    total = num1 + num2  # Logical Error: Cannot add string and integer
    print(f"Total: {total}")
    print("You qualify for the next round!")

team14()
