def team15():
    lst = [5, 10, 15]
    print(lst[4])  # Logical Error: Index out of range
    print("You qualify for the next round!")

team15()
