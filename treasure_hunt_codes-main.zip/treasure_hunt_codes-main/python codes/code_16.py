def team16():
    x = 0
    if x == "0":  # Logical Error: Type mismatch
        print("Zero as a string")
    print("You qualify for the next round!")

team16()
