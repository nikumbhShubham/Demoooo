def team17():
    x = [1, 2, 3]
    x[3] = 4  # Logical Error: Index out of range
    print(x)
    print("You qualify for the next round!")

team17()
