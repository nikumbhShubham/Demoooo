def team18():
    a = [10, 20, 30]
    b = a + 5  # Logical Error: Cannot add a list and an integer
    print(b)
    print("You qualify for the next round!")

team18()
