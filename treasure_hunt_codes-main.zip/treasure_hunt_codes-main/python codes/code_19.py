def team19():
    result = 100 / 0  # Logical Error: Division by zero
    print(result)
    print("You qualify for the next round!")

team19()
