def team20():
    a = 10
    if a = 10:  # Syntax Error: Assignment uses single =
        print("a is equal to 10")
    print("You qualify for the next round!")

team20()
