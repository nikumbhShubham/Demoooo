def team3():
    a = 5
    b == 10  # Syntax Error: Assignment uses single =
    if a > b:  # Logical Error: Condition will always be False
        print("a is greater")
    print("You qualify for the next round!")

team3()
