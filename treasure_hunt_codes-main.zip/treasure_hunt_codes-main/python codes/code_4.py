def team4():
    n = [1, 2, 3]
    print(n{2})  # Syntax Error: Incorrect indexing syntax, should use []
    if len(n) > 5:  # Logical Error: Condition is unlikely to be True
        print("List is long!")
    print("You qualify for the next round!")

team4()
