def team6():
    string = "Welcome"
    if string.find("Z") = -1:  # Syntax Error: Comparison should use ==
        print("Letter not found")
    print("You qualify for the next round!")

team6()
