def team7():
    nums = [10, 20, 30]
    result = nums.pop(3)  # Logical Error: Index out of range
    print(result)
    print("You qualify for the next round!")

team7()
