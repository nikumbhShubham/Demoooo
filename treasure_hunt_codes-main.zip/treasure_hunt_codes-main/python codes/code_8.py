def team8():
    a = 25
    if a % 2 == 1:
        print("Even number")  # Logical Error: Prints incorrect description
    print("You qualify for the next round!")

team8()
